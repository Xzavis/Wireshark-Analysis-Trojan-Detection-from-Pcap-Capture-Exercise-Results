# Wireshark-Training
Collection of Wireshark resources &amp; PCAP files used in the Blue Team training course

# Note
- The zipped Dridex PCAP archive is password protected, to unencrypt it, use the password "infected"
